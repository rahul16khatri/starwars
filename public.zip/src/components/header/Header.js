import React from 'react'
import '../../App.css'

const Header = () => {
    return (
        <header></header>
    )
}

export default Header;